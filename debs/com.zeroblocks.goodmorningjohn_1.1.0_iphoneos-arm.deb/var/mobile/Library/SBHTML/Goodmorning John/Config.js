var name = "John";  // Your name
var degrees = "C";  // Degrees: C or F
