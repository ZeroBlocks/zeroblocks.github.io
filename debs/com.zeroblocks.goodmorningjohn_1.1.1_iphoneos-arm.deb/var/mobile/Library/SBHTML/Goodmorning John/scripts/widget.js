/* Goodmorning John Script By ZeroBlocks */

$(document).ready(function() {
  function startTime() {
    var greeting;

    var today = new Date();
    var hours = today.getHours();
    var minutes = today.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';

    var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var day = weekday[today.getDay()];

    var month = ["January","February","March","April","May","June", "July", "August", "September", "October", "November", "December"];
    var date = month[today.getMonth()] + ' ' + today.getDate();

    hours = hours % 12;
    hours = hours ? hours : 12;

    if (ampm == 'am' ) {
      if ((hours <= 5 ) || (hours == 12)) {
        greeting = 'Good night';
      } else {
        greeting = 'Good morning';
      }
    } else {
      if ((hours <= 5 ) || (hours == 12)) {
        greeting = 'Good afternoon';
      } else {
        greeting = 'Good evening';
      }
    }

    hours = checkTime(hours);
    minutes = checkTime(minutes);

    $('.greeting').html(greeting);
    $('.name').html(name);
    $('.time').html(hours + ":" + minutes);
    $('.ampm').html(ampm);
    $('.day').html(day);
    $('.date').html(date);
    $('.degrees').html(degrees);

    var timeOut = setTimeout(startTime, 1000); // recheck time every second

    function checkTime(i) { // add zero in front of numbers < 10
      if (i < 10) {
        i = "0" + i
      };
      return i;
    }
  }

  startTime();
});
