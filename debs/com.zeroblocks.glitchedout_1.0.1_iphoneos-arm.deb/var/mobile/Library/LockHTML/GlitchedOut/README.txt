Glitchy XenHTML Lockscreen Clock, made from scratch.

Author: ZeroBlocks
----------------------
Reddit: 	/u/ZeroBlocks
Twitter: 	@ZeroBlocks