XenHTML widget for Homescreen, set name in settings.

Author: ZeroBlocks
----------------------
Reddit: 	/u/ZeroBlocks
Twitter: 	@ZeroBlocks