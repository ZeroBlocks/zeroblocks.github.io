This is my first XenHTML Clock, made from scratch to my personal preferences.

Author: ZeroBlocks
----------------------
Reddit: 	/u/ZeroBlocks
Twitter: 	@ZeroBlocks