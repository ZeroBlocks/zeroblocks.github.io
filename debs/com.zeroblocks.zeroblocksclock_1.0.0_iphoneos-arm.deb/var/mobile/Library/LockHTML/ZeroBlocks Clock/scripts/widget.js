$(document).ready(function() {
  function startTime() {
    var today = new Date();
    var hours = today.getHours();
    var minutes = today.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var day = weekday[today.getDay()];
    var month = ["January","February","March","April","May","June", "July", "August", "September", "October", "November", "December"];
    var date = month[today.getMonth()] + ' ' + today.getDate();

    hours = hours % 12;
    hours = hours ? hours : 12;
    hours = checkTime(hours);
    minutes = checkTime(minutes);

    $('.time').html(hours + ":" + minutes);
    $('.ampm').html(ampm);
    $('.day').html(day);
    $('.date').html(date);

    var timeOut = setTimeout(startTime, 10000); // recheck time every 10 seconds

    function checkTime(i) {
      if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
      return i;
    }
  }

  startTime();
});
