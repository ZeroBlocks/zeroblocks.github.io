XenHTML widget for Lockscreen - TLAB Logo with glitch

Author: ZeroBlocks
----------------------
Reddit: 	/u/ZeroBlocks
Twitter: 	@ZeroBlocks